package test.paulstasiuk.com;

import android.app.Activity;


import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.EditText;
import java.util.Stack;
import java.util.*;

public class NeedlemanWunsch extends Activity{
	private  EditText sequence1;
	private  EditText sequence2;
	private TextView topText;
	private TextView rightText;
	private TextView alignedSequence1;
	private TextView alignedSequence2;
	private TextView numberMatrix;
	private Button align;
	private Button back;
	protected String seq1;
	protected String seq2;
	protected int x;
	protected int y;
	protected boolean isSW;
	public Character dash;
	public Stack sequenceAlign1;
	public Stack sequenceAlign2;
	public MatrixNode[][] matrix;

	 	@Override
	    public void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.needleman);
	        
	        
	        sequence1= (EditText) findViewById(R.id.edittext1);
	        sequence2= (EditText) findViewById(R.id.edittext2);
	        topText= (TextView) findViewById(R.id.topText);
	        rightText= (TextView) findViewById(R.id.rightText);
	        alignedSequence1= (TextView) findViewById(R.id.alignedSeqence1);
	        alignedSequence2= (TextView) findViewById(R.id.alignedSeqence2);
	        numberMatrix=(TextView) findViewById(R.id.numberMatrix);
	        align= (Button) findViewById(R.id.needlemanAlign);
	        
	        
	        align.setOnClickListener( new View.OnClickListener() {
				public void onClick(View v) {
					rightText.setText("");
					topText.setText("");
					alignedSequence1.setText("");
					alignedSequence2.setText("");
					numberMatrix.setText("");
					//alignedSequence1.setText(Integer.toString(sequence1.getText().toString().length()));
					//alignedSequence2.setText(Integer.toString(sequence2.getText().toString().length()));
					returnHorizon(returnSeq1());
					returnVert(returnSeq2());
					matrixNW(returnSeq1(),returnSeq2(),false);
					fillMatrix(-1,-1,2);
					findPath();
					returnAligned();
					printMatrix();
				}
			});
	        
	        back= (Button) findViewById(R.id.back);
	        back.setOnClickListener( new View.OnClickListener() {
				public void onClick(View v) {
					Intent intent= new Intent();
					setResult(RESULT_OK, intent);
					finish();
				}
			});
	 }
	
	public void returnHorizon(String horzText){
		char array[]= horzText.toCharArray();
		topText.append("  ");
	    for (int i=0; i<=array.length-1; i++){
	    	topText.append(array[i]+" ");
	    }
	   	
	  }
	public void returnVert(String vertText){
		char array[]= vertText.toCharArray();
	    for(int i=0; i<=array.length-1; i++){
	    	rightText.append(array[i]+"\n");
	    	//System.out.println(rightText.getText());
	    }
	    	
	 }

	public String returnSeq1(){
		return sequence1.getText().toString();
		}
	public String returnSeq2(){
		return sequence2.getText().toString();
		}
	
	 public void matrixNW(String in1, String in2, boolean type){  
		 	seq1=in1;
		 	seq2=in2;
	        x = sequence1.getText().toString().length()-1;
	        y = sequence2.getText().toString().length()-1;
	        isSW=type;
	        matrix = new MatrixNode[x+2][y+2];
	    }
	        
	       public void fillMatrix(int mismatch, int gap, int match){
	        
	           int score, pathX, pathY;
	           String outcome;
	        //intialize left column 
	        for(int a = 0; a <= y; a++){
	            if(isSW == true){score = 0;}
	            else{score = 0-a;}
	            pathX = 0;
	            pathY = 0;
	            outcome = "EDGE";
	            matrix[a][0] = new MatrixNode(score, pathX, pathY, outcome);           
	        }
	        //initialize top row
	        for(int a = 0; a <= x; a++){
	            if(isSW){score = 0;}
	            else{score = 0-a;}
	            pathX = 0;
	            pathY = 0;
	            outcome = "EDGE";
	            matrix[0][a] = new MatrixNode(score, pathX, pathY, outcome);
	        }
	    
	   
	        for(int a = 1; a <= y; a++){
	            //System.out.println(" ");
	            for(int b = 1; b <= x; b++){
	                
	                matrix[a][b] = new MatrixNode(0, 0, 0, null);
	                matrix[0][0] = new MatrixNode(0,0,0,null);
	                
	                if(seq1.charAt(b-1) == seq2.charAt(a-1)){
	                    score = matrix[a-1][b-1].returnScore() + match;
	                    if(isSW == true && score < 0){score = 0;}
	                    pathX = b-1;
	                    pathY = a-1;
	                    outcome = "MATCH";        
	                    matrix[a][b].setScore(score, pathX, pathY, outcome);
	                }
	                else{
	                    int scoreUp = matrix[a-1][b].returnScore() + gap;
	                    int scoreLeft = matrix[a][b-1].returnScore() + gap;
	                    int scoreDia = matrix[a-1][b-1].returnScore() + mismatch;
	                    
	                    if(scoreUp > scoreLeft && scoreUp > scoreDia){
	                        if(isSW == true && scoreUp < 0){scoreUp = 0;}
	                        pathX = b;
	                        pathY = a-1;
	                        outcome = "GAP";
	                        matrix[a][b].setScore(scoreUp, pathX, pathY, outcome);
	                    }
	                    else if(scoreLeft > scoreUp && scoreLeft > scoreDia){
	                        if(isSW == true && scoreLeft < 0){scoreLeft = 0;}
	                        pathX = b-1;
	                        pathY = a;
	                        outcome = "GAP";
	                        matrix[a][b].setScore(scoreLeft, pathX, pathY, outcome);
	                    }
	                    else if(scoreDia > scoreUp && scoreDia > scoreLeft){
	                        if(isSW == true && scoreDia < 0){scoreLeft = 0;}
	                        pathX = b-1;
	                        pathY = a-1;
	                        outcome = "MISS";
	                        matrix[a][b].setScore(scoreDia, pathX, pathY, outcome);
	                    }
	                }                
	            }
	        }
	    
	    }
	        
	       public void findPath(){
	            
	            int max = 0;
	            int seqX = 0;
	            int seqY = 0;
	            int place = 0;
	            int length = 0;
	            sequenceAlign1 = new Stack();
	            sequenceAlign2 = new Stack();
	           
	            //if called as Smith-Watermann, then find maximum.  Else start from end of matrix
	           if(isSW == true){ 
	               for(int a = 1; a <= sequence2.toString().length(); a++){
	                    for(int b = 1; b <= sequence1.toString().length(); b++){
	                        if(matrix[a][b].returnScore() > max){
	                            max = matrix[a][b].returnScore();
	                            seqX = b;
	                            seqY = a;
	                        }   
	                    }
	                    System.out.println("Max Co: " + seqX + "," + seqY);
	                }
	                System.out.println("Last Score: " + matrix[seq2.length()][seq1.length()].returnScore());
	            }
	            else if(!isSW){
	                seqX = seq1.length()-1;
	                seqY = seq2.length()-1;
	                System.out.println("NW");
	            }
	    
	        System.out.println("");
	        System.out.println("Maximum coordinates : " + seqX + "," + seqY);
	        
	        //trace back decrementally from maximum coordinate (a,b)
	            for(int a = seqY; a > 0;){
	                for(int b = seqX; b > 0;){
	            
	                    //If node is a match, pull char from same position in respective input seq and
	                    //insert into alignment
	                    //If node is a gap (coordinate pointed to < coordinate of node), insert gap into
	                    //appropriate alignment sequence
	                    //Decrement until loop reaches edge (x or y > 0)
	                    if(isSW == true && matrix[a][b].returnScore() == 0){
	                        a = 0;
	                        b = 0;
	                    }
	                    else{
	                        if(matrix[a][b].returnOutcome() == "MATCH" || matrix[a][b].returnOutcome() == "MISS"){
	                            sequenceAlign1.push(seq1.charAt(b-1));
	                            sequenceAlign2.push(seq2.charAt(a-1));
	                            a--;
	                            b--;
	                        }
	                        else{
	                            if(matrix[a][b].returnPathX() < b){
	                                sequenceAlign1.push(seq1.charAt(b-1));
	                                sequenceAlign2.push("-");
	                                b--;
	                            }
	                            else if(matrix[a][b].returnPathY() < a){
	                                sequenceAlign1.push("-");
	                                sequenceAlign2.push(seq2.charAt(a-1));
	                                a--;
	                            }
	                        }
	                    }
	                }
	            }
	            
	    }

      public MatrixNode[][] returnMatrix(){
          return matrix;
      }
	       
	       public void printMatrix(){
	            for(int y = 0; y < seq2.length(); y++){
	                numberMatrix.append(" ");
	                for(int x = 0; x < seq1.length(); x++){
	                    numberMatrix.append(Integer.toString(matrix[x][y].returnScore()));
	                }
	            }
	        }
	        
	        public void returnAligned(){ 
	        	
	        
	            while(!sequenceAlign1.isEmpty()){
	              alignedSequence1.append(sequenceAlign1.pop().toString());
	            }
	            
	            while(!sequenceAlign2.isEmpty()){
	            	alignedSequence2.append(sequenceAlign2.pop().toString());
	            }
	            
	        }
	}
