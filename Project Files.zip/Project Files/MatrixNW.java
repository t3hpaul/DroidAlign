/*Class describing SimilarityMatrix, 
used for scoring similarity of two sequences */

public class MatrixNW
{
	protected MatrixNode matrix[][];
	protected int x;
	protected int y;
	protected String seq1;
	protected String seq2;
	
	public matrixNW(String in1, String in2){
	
	//Read in sequences, get lengths for matrix sizing
		
	seq1 = in1;
	seq2 = in2;
	x = seq1.length();
	y = seq2.length();
	boolean max;
	
	//Create 2D array of matrix nodes
	matrix = new MatrixNode[x+1][y+1];
		
	}
	
	public void fillMatrix(String seq1, String seq2, int mismatch, int gap, int match ){
		
		for(int a = 0; a < this.x; a++){
			int score = 0-a;
			String path = "EDGE";
			String symbol = "EDGE";
			this.matrix(a,0).setScore(score, path, symbol);
		}
		
		for(int a = 0; a < this.x; a++){
			int score = 0-a;
			String path = "EDGE";
			String symbol = "EDGE";
			this.matrix(0,a).setScore(score, path, symbol);
		}
		
		
		for(int a = 1; a < this.y; a++){
			for(int b = 1; b < this.x; b++){
				this.matrix[a,b] = new MatrixNode(0,null,null)
				
				if(seq1.charAt(b) == seq2.charAt(a)){
					int score = this.matrix(a-1,b-1).returnScore() + match;
					String path = "DIAG";
					String outcome = "MATCH";
				}
				else{
					int scoreUp = this.matrix(a-1,b).returnScore() + gap;
					int scoreLeft = this.matrix(a,b-1).returnScore() + gap;
					int scoreDia = this.matrix(a-1,b-1).returnScore() + mismatch;
					
					if(scoreUp > scoreLeft && scoreUp > scoreDia){
						String path = "UP";
						String outcome = "GAP";
						this.matrix(a,b).setScore(scoreUp, path, outcome);
					}
					else if(scoreLeft > scoreUp && scoreLeft > scoreDia){
						String path = "LEFT";
						String outcome = "GAP";
						this.matrix(a,b).setScore(scoreLeft, path, outcome);
					}
					else if(scoreDia > scoreUp && scoreDia > scoreLeft){
						String path = "DIAG";
						
					}
					}
			if(this.matri[a,b].returnScore())
				
			}
		}
	}
	
	public void findPath(){
		for(int a = 1; a < this.y;){
			for(int b = 1; b)
		}
	}
}