/*Class describing directed graph that will be used to calculate correct
path back through matrix to determine correct alignment
Zachary Romer, Paul Stasiuk
11/7/10 
*/

public class TraceGraph
{



}