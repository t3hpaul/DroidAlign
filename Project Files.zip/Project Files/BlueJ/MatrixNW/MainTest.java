/**
 * Write a description of class MainTest here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MainTest
{
    public static void main(String[] args){
        
    MatrixNode test1 = new MatrixNode(0, 0, 0, "GAP");
    
    String seq1 = "TGCATTT";
    String seq2 = "TCGCT";
   
    MatrixNW test2 = new MatrixNW(seq1,seq2, false);
    test2.fillMatrix(-1,-1,2);
    test2.printMatrix();
    test2.findPath();
    test2.returnAligned();
    }
}
